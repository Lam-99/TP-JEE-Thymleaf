package com.example.tpjee;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TpJeeApplicationTests {

    @Test
    void contextLoads() {
    }

}
